package in.bloodsync.pojo;

public class BloodStockPojo {
	private String bloodType;
	private int availableUnits;
	private int donatedUnits;
	private int totalUnits;
	public String getBloodType() {
		return bloodType;
	}
	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}
	public int getAvailableUnits() {
		return availableUnits;
	}
	public void setAvailableUnits(int availableUnits) {
		this.availableUnits = availableUnits;
	}
	public int getDonatedUnits() {
		return donatedUnits;
	}
	public void setDonatedUnits(int donatedUnits) {
		this.donatedUnits = donatedUnits;
	}
	public int getTotalUnits() {
		return totalUnits;
	}
	public void setTotalUnits(int totalUnits) {
		this.totalUnits = totalUnits;
	}
	
	
	
	

	
	
	
	

}
