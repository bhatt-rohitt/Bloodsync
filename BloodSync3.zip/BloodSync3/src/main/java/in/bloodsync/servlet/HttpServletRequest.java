package in.bloodsync.servlet;

public class HttpServletRequest {

}
