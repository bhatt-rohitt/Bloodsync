package in.bloodsync.servlet;

public class ServletException {

}
