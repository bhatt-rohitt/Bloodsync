# BloodSync-Application
A bloodsync application where donors can donate blood and hospitals can requests for blood.
